<?php
include 'conn.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $pass = $_POST['password'];


  $conn->query("INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$pass')");
  echo "Registration successful. <a href='login.html'>Login here</a>";
}
?>


