<?php
session_start();
include 'conn.php';

if (!isset($_SESSION['email'])) {
  header("Location: login.html");
  exit();
}

$email = $_SESSION['email'];
$user = $conn->query("SELECT * FROM users WHERE email='$email'")->fetch_assoc();
$user_id = $user['id'];
?>

<h2>Welcome, <?php echo $user['name']; ?> | <a href='logout.php'>Logout</a></h2>

<form method="POST" action="submit_toll.php">
  <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
  
  <input type="text" name="vehicle_number" placeholder="Vehicle Number" required><br><br>

  <select name="vehicle_type" required>
    <option value="">Select Vehicle Type</option>
    <option value="Car">Car</option>
    <option value="Truck">Truck</option>
    <option value="Bike">Bike</option>
    <option value="Bus">Bus</option>
  </select><br><br>

  <input type="text" name="toll_location" placeholder="Toll Plaza Location" required><br><br>

  <input type="number" name="toll_amount" placeholder="Toll Amount" required><br><br>

  <input type="submit" value="Submit Toll Payment">
</form>
