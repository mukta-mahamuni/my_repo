
<!DOCTYPE html>
<html>
<body>
<h2>Login</h2>
<form method="POST" action="login.php">
  <input type="email" name="email" placeholder="Email" required><br><br>
  <input type="password" name="password" placeholder="Password" required><br><br>
  <input type="submit" value="Login">
</form>
</body>
</html>
