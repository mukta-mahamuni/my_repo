<?php
include 'conn.php';

if (isset($_GET['resolve'])) {
  $id = $_GET['resolve'];
  $conn->query("UPDATE tolls SET status='Paid' WHERE id=$id");
}

$result = $conn->query("SELECT t.id, u.name, t.vehicle_number, t.vehicle_type, t.toll_location, t.toll_amount, t.status, t.date 
                        FROM tolls t JOIN users u ON t.user_id = u.id");

echo "<h2>Admin Dashboard - Toll Entries</h2>";
while ($row = $result->fetch_assoc()) {
  echo "<p>
    <b>User:</b> {$row['name']}<br>
    <b>Vehicle No:</b> {$row['vehicle_number']} ({$row['vehicle_type']})<br>
    <b>Location:</b> {$row['toll_location']}<br>
    <b>Amount:</b> ₹{$row['toll_amount']}<br>
    <b>Date:</b> {$row['date']}<br>
    <b>Status:</b> {$row['status']}<br>";

  if ($row['status'] == 'Pending') {
    echo "<a href='admin.php?resolve={$row['id']}'>Mark as Paid</a>";
  }

  echo "</p><hr>";
}
?>
