<?php
include 'conn.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $user_id = $_POST['user_id'];
  $vehicle_number = $_POST['vehicle_number'];
  $vehicle_type = $_POST['vehicle_type'];
  $toll_location = $_POST['toll_location'];
  $toll_amount = $_POST['toll_amount'];
  $date = date('Y-m-d H:i:s');

  $sql = "INSERT INTO tolls (user_id, vehicle_number, vehicle_type, toll_location, toll_amount, status, date)
          VALUES ('$user_id', '$vehicle_number', '$vehicle_type', '$toll_location', '$toll_amount', 'Pending', '$date')";

  if ($conn->query($sql)) {
    echo "Toll payment submitted successfully.<br><a href='dashboard.php'>Go back</a>";
  } else {
    echo "Error: " . $conn->error;
  }
}
?>
