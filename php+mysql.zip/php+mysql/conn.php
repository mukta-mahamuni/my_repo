<?php
$conn = new mysqli("localhost", "root", "", "college_admission");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>
