// Show an alert
alert("Welcome! Let's explore some fun JavaScript basics! 🎉");

// Variables
const averageLifespanYears = 72;
const weeksInYear = 52;
const averageWeeks = averageLifespanYears * weeksInYear;
const greeting = "👋 Hey there! This is a quick JavaScript demo for you.";

// Time of day
const hour = new Date().getHours();
let timeMessage = "";

if (hour < 12) {
  timeMessage = "🌅 Rise and shine! Good Morning!";
} else if (hour < 18) {
  timeMessage = "☀️ Hope your day is going well. Good Afternoon!";
} else {
  timeMessage = "🌙 It's getting late! Good Evening or Night!";
}

// Fun fact message
const funFact = `💡 Did you know? If you live up to ${averageLifespanYears} years, 
you’ll experience approximately ${averageWeeks.toLocaleString()} weeks! That’s a lot of Mondays 😅`;

// Prepare output
const outputHTML = `
  <p>${greeting}</p>
  <p>${timeMessage}</p>
  <p>${funFact}</p>
  <hr>
  <p><em>JavaScript is running in the background like a silent ninja 🥷</em></p>
`;

// Show in browser
document.getElementById("output").innerHTML = outputHTML;
